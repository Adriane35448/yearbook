<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>ICpEP.SE Student Yearbook Management System</title>
	<link rel="stylesheet" href="istyle.css">
    <link rel="stylesheet" href="astyle.css">
    <style>
		body {
		    background: url('background.jpg') no-repeat;
		    background-size: cover;
		    background-position: center;
		}
        .about-container .about-content {
            color: #fff;
        }
	</style>
</head>
<body>
	<header class="header">
		<a href="dashboard.php" class="logo">
	        <ion-icon name="shield-checkmark-outline"></ion-icon>ICpEP. Student Yearbook Management System
		</a>
		<nav class="nav">
		    <a href="dashboard.php">Home</a>
		    <a href="#">Gallery</a>
		    <a href="about2.php">About Us</a>
		    <a href="#">Account</a>
		</nav>
	</header>

    <div class="about-container">
	    <div class="about-content">
	        <h2>VISION</h2>
	        <p>
                The premier technological university in the region providing transformative education 
                where graduates are globally competitive, innovative, and responsive to the demands 
                of a changing world.

	        </p>
		</div>
        <div class="about-content">
	        <h2>MISSION</h2>
	        <p>
                NwSSU shall lead in providing highly technical and professional education 
                and lifelong learning in the trade, fishery, agriculture, science, education, 
                commerce, engineering, forestry, nautical, and other emerging programs in the digital age. 
                It shall generate cutting-edge technology and undertake sustainable community development 
                in accordance with the university mandates, thrusts, and directions.

	        </p>
		</div>
        <div class="about-content">
	        <h2>GOALS OF THE COLLEGE</h2>
            <h3>(College of Engineering and Architecture)</h3>
	        <p>
                The College of Engineering and Architecture shall spearhead in the holistic development of students
                and achieved a status capable of administering effectively-outcomes based education, research, 
                extension services that meet professional and technical needs of local and international industries.
	        </p>
		</div>
	</div>




	</section>
	<div class="footer">
		<div class="top">
		    <div class="container">
		        <div class="textwidget">
		            <p>
		                <span class="address">
		                    Northwest Samar State University | College of Engineering and Architecture | Rueda Street, Calbayog City 6710, Philippines
		                    <br>
		                    Contact Us by <a href="mailto:signup@nwssuybms.edu">e-mail</a>
		                </span>
		                <span class="copyright">© 2024 ICpEP.SE Student Yearbook Management System. All Rights Reserved.</span>
		            </p>
		        </div>
		            <div class="social-links center-mobile">
		                <span class="followus">Follow Us</span>
		                <a href="#"><ion-icon name="logo-facebook"></ion-icon></a>
		                <a href="#"><ion-icon name="logo-instagram"></ion-icon></a>
		            </div>
		    </div>
		</div>
	</div>
		<script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
		<script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
</body>
</html>

